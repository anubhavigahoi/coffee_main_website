let shopItemsData = [
  {
    id: "jfhgbvnscs",
    name: "Black Coffee",
    price: 15.99,
    img: "images/menu-1.png",
  },
  {
    id: "ioytrhndcv",
    name: "Espresso",
    price: 17.99,
    img: "images/menu-2.png",
  },
  {
    id: "wuefbncxbsn",
    name: "Americano",
    price: 20.99,
    img: "images/menu-3.png",
  },
  {
    id: "thyfhcbcv",
    name: "Cold Brew",
    price: 18.99,
    img: "images/menu-4.png",
  },
  {
    id: "thyfhcbcv",
    name: "Cappuccino",
    price: 14.99,
    img: "images/menu-5.png",
  },
  {
    id: "thyfhcbcv",
    name: "Cold Coffee",
    price: 16.99,
    img: "images/menu-6.png",
  },
];
